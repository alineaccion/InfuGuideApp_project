//
//  EnumsTypes.swift
//  InfuApp
//
//  Created by Alicia Moreno Alvarez on 14/09/2020.
//  Copyright © 2020 Alicia Moreno Alvarez. All rights reserved.
//

import Foundation
/*
 enum InfuType {
    case estimulante
    case relajante
    case saludable
}
 */
